<div class="content_bg">
<div class="wrap">
<div class="wrapper">

        
			<div class="grid_s">
				<h2>Noticias</h2>
				 <div class="grid">
				 	<div class="gallery">
						<a href="views/images/grids-img4.jpg"><img src="views/images/grids-img4.jpg" title="image-name"></a>
					</div>
					<h3>the rhoncus neque</h3>
					<div class="grid_p">
					<p>Lorem ipsum dolor sit amet consectetur adiing elit. In volutpat luctus eros ac placerat. Quisque erat metus facilisis non feu,aliquam hendrerit quam. Donec ut lectus vel dolor adipiscing tincnt.</p>
					<a class="button bg2 grid_btn" href="details.html">read  more</a>
					</div>
				</div>
				<div class="grid">
					<div class="gallery">
						<a href="views/images/grids-img5.jpg"><img src="views/images/grids-img5.jpg" title="image-name"></a>
					</div>
					<h3> ut hendrerit lipsum</h3>
					<div class="grid_p">
					<p>Lorem ipsum dolor sit amet consectetur adiing elit. In volutpat luctus eros ac placerat. Quisque erat metus facilisis non feu,aliquam hendrerit quam. Donec ut lectus vel dolor adipiscing tincnt.</p>
					<a class="button bg1 grid_btn" href="details.html">read more</a>
					</div>
				</div>
				<div class="grid last-grid">
					<div class="gallery">
						<a href="views/images/grids-img5.jpg"><img src="views/images/grids-img6.jpg" title="image-name"></a>
					</div>
					<h3>Proin vehicula justo</h3>
					<div class="grid_p">
					<p>Lorem ipsum dolor sit amet consectetur adiing elit. In volutpat luctus eros ac placerat. Quisque erat metus facilisis non feu,aliquam hendrerit quam. Donec ut lectus vel dolor adipiscing tincnt.</p>
					<a class="button bg3 grid_btn" href="details.html">read more</a>
					</div>
				</div>
				<div class="clear"> </div>
			</div>
			<div class="grid_s1">
				 <div class="grid">
				 	<div class="gallery">
						<a href="views/images/grids-img1.jpg"><img src="views/images/grids-img1.jpg" title="image-name"></a>
					</div>
					<h3>Proin vehicula justo</h3>
					<div class="grid_p">
					<p>Lorem ipsum dolor sit amet consectetur adiing elit. In volutpat luctus eros ac placerat. Quisque erat metus facilisis non feu,aliquam hendrerit quam. Donec ut lectus vel dolor adipiscing tincnt.</p>
					<a class="button bg4 grid_btn" href="details.html">read more</a>
					</div>
				</div>
				<div class="grid">
					<div class="gallery">
						<a href="views/images/grids-img1.jpg"><img src="views/images/grids-img2.jpg" title="image-name"></a>
					</div>
					<h3>the rhoncus neque</h3>
					<div class="grid_p">
					<p>Lorem ipsum dolor sit amet consectetur adiing elit. In volutpat luctus eros ac placerat. Quisque erat metus facilisis non feu,aliquam hendrerit quam. Donec ut lectus vel dolor adipiscing tincnt.</p>
					<a class="button bg5 grid_btn" href="details.html">read more</a>
					</div>
				</div>
				<div class="grid last-grid">
					<div class="gallery">
						<a href="views/images/grids-img3.jpg"><img src="views/images/grids-img3.jpg" title="image-name"></a>
					</div>
						<h3> ut hendrerit lipsum</h3>
					<div class="grid_p">
					<p>Lorem ipsum dolor sit amet consectetur adiing elit. In volutpat luctus eros ac placerat. Quisque erat metus facilisis non feu,aliquam hendrerit quam. Donec ut lectus vel dolor adipiscing tincnt.</p>
					<a class="button bg6 grid_btn" href="details.html">read more</a>
					</div>
				</div>
				<div class="clear"> </div>
			</div>
</div>
</div>
</div>
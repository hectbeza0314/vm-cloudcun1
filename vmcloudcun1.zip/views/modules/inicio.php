<div class="content_bg">
<div class="wrap">
<div class="wrapper">
	<?php

		echo "El Servidor Actual Es - ".gethostname();

	?>
</div>
</div>
</div>
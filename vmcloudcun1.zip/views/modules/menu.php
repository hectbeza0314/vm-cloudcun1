
<div class='cssmenu'>
	<ul>
	   	<li class='active'><a href='index.php'><span>Inicio</span></a></li>
		<li><a href='index.php?action=nosotros'><span>Nosotros</span></a></li>
        <li class='has-sub'><a href='index.php?action=servicios'><span>Servicios</span></a></li>
		<li class='last'><a href='index.php?action=contactenos'><span>Contactenos</span></a></li>
	    <div class="clear"></div>
	</ul>
</div>
<div class="search">
    		<form>
    		</form>
</div>
<div class="clear"></div>
<!--A Design by W3layouts
Author: W3layout
Author URL: http://w3layouts.com
License: Creative Commons Attribution 3.0 Unported
License URL: http://creativecommons.org/licenses/by/3.0/
-->
<!DOCTYPE HTML>
<html>
<head>
<title>Alumbrados de Oriente</title>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1">
<link href='//fonts.googleapis.com/css?family=Marcellus+SC' rel='stylesheet' type='text/css'>
<link href="views/css/style.css" rel="stylesheet" type="text/css" media="all" />
</head>
<body>
<!--start header-->

<!-- start content -->
<div class="content_bg">
<div class="wrap">
<div class="wrapper">
<div class="main">
	 	<h2>Quienes somos</h2>
		<div class="about">
			 <div class="cont-grid-img img_style">
	     		<a href="index.php?action=servicios"><img src="views/images/about_pic.jpg" alt=""></a>
	     	</div>
	       <div class="cont-grid">
	       <div class="abt-para">
	       	<span>Alumbrados de Oriente SAS</span>
	       	<p class="para">Lorem Ipsum is simply dummy text of the printing and typesetting industry., Lorem Ipsum  dummy text ever since dummy text of the printing and usings 1500s,Duis aute irure dolor in reprehenderit in voluptate velit esse when an,Lorem Ipsum has been the industry's standard dummy text ever since dummy text of the printing and usings 1500s, </p>
	       	<p class="para">There are many variations of passages of Lorem Ipsum available, but the majority have suffered alteration in some form, by injected humour, or randomised words which don't look even slightly believable. If you are going to use a passage of Lorem Ipsum, you need to be sure there isn't anything embarrassing hidden in the middle of text.</p>
	       	</div>
	      	<div class="clear"></div>
	      	</div>
	      	<div class="clear"></div>
	    	<div class="about-p">
                <div class="about">
                    <h2>Misión</h2>
			    </div></br></br>
		    	    <p class="para">ALUMBRADOS DE ORIENTE S.A.S Somos una empresa de la región comprometida con la prestación optima del servicio de alumbrado público, siempre orientada a contribuir con la seguridad, bienestar, desarrollo urbanístico, social y ambiental de los municipios de Restrepo y Cumaral en sus áreas, urbana y rural.</p>
		</div>
		</div>

        <div class="clear"></div>
	    	<div class="about-p">
                <div class="about">
                    <h2>Visión</h2>
			    </div></br></br>
		    	    <p class="para">ALUMBRADOS DE ORIENTE S.A.S Nos proyectamos para el año 2025 consolidarnos como una de las empresas líderes en la prestación del servicio de alumbrado público en el meta, logrando mantenernos a la vanguardia con los avances tecnológicos y la protección del medio ambiente. Brindar un excelente ambiente laboral a nuestros colaboradores, donde se fortalezcan los conocimientos del talento humano y así se garantice la satisfacción de las necesidades de nuestros usuarios.</p>				    
		</div>
		</div>

        <div class="clear"></div>
	    	<div class="about-p">
                <div class="about">
                    <h2>Objetivos de Misón Intergral</h2>
			    </div></br></br>
		    	    <p class="para">* Asegurar el cumplimiento en la prestación del servicio de alumbrado publico.</p></br>
                    <p class="para">* Garantizar la identificación, evaluación y control de los peligros asociados al desarrollo de las actividades derivadas de la prestación del servicio de alumbrado público, estableciendo medidas para prevenirlos y para mitigarlos, evitando la ocurrencia de lesiones por accidentes de trabajo y enfermedades laborales que puedan afectar la salud de los trabajadores, clientes y demás partes interesadas.</p></br>
                    <p class="para">* Fortalecer la prevención de los impactos ambientales generados por las actividades administrativas y operativas para la prestación del servicio de alumbrado público, adoptando medidas para la disminución y control de la contaminación y daños al medio ambiente.</p></br>
                    <p class="para">* Asegurar el cumplimiento en la prestación del servicio de alumbrado publico.</p></br>
                    <p class="para">* Asegurar la evaluación del cumplimiento de los requisitos legales y reglamentarios vigentes aplicables en materia calidad, medio ambiente, seguridad y salud en el trabajo, así como otros requisitos que la organización suscriba antes sus clientes, proveedores, comunidad, estado, y demás partes interesadas.</p></br>
                    <p class="para">* Garantizar la consulta, y participación de personal en las actividades y toma de decisiones.</p></br>
                    <p class="para">* Asegurar la disponibilidad de los vehículos, equipos, herramientas, e instalaciones en optimas condiciones de funcionalidad para garantizar la prestación del servicio de alumbrado público.</p></br>
                    <p class="para">* Garantizar que el personal de la empresa cumpla con el perfil de competencias requeridas para cada cargo, realizando las actividades de formación y capacitación de dos colaboradores, contribuyendo al crecimiento y desarrollo de sus competencias.</p></br>
                    <p class="para">* Gestionar las adquisiciones de los bienes y servicios asegurando el cumplimiento y estándares de Calidad Medio Ambiente Segundad y Salud en el Trabajo por parte de los proveedores y contratistas.</p></br>
                    <p class="para">* Aumentar la rentabilidad de la empresa, procurando por el crecimiento y bienestar de los trabajadores, contratistas, proveedores y socios de la organización.</p></br>
                    <p class="para">* Asegurar el mejoramiento continuo de cada uno de los procesos de la organizadón, implementando eficazmente las acciones de mejorar para el SIG.</p></br>
		</div>
		</div>

</div>
</div>
</div>

</body>
</html>
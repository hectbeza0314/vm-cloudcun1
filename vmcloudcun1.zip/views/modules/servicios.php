<?php

echo "Soy la maquina".gethostname();

?>
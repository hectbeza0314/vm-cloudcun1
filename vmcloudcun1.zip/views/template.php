<!--A Design by W3layouts
Author: W3layout
Author URL: http://w3layouts.com
License: Creative Commons Attribution 3.0 Unported
License URL: http://creativecommons.org/licenses/by/3.0/
-->
<!DOCTYPE HTML>
<html>
<head>
<title>Alumbrados de Oriente</title>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1">
<link href='//fonts.googleapis.com/css?family=Marcellus+SC' rel='stylesheet' type='text/css'>
<link href="views/css/style.css" rel="stylesheet" type="text/css" media="all" />
	<!--start slider -->
		<script src="views/js/jquery.min.js"></script>
		<script src="views/js/responsiveslides.min.js"></script>
		  <script>
		    // You can also use "$(window).load(function() {"
			    $(function () {
			
			      // Slideshow 1
			      $("#slider1").responsiveSlides({
			        maxwidth: 1600,
			        speed: 600
			      });
			});
		  </script>
<!--start lightbox -->
<link rel="stylesheet" type="text/css" href="views/css/jquery.lightbox.css">
<script src="views/js/jquery.lightbox.js"></script>
<script>
  // Initiate Lightbox
  $(function() {
    $('.gallery a').lightbox(); 
  });
</script>
</head>
<body>
<!--start header-->
<div class="h_bg">
<div class="wrap">
<div class="wrapper">
	<div class="header">
		<div class="logo">
			 <a href="index.php"><img src="views/images/logo-cun.png"> </a>
			 <a href="index.php"><img src="views/images/Logo2.png"> </a>
			 
		</div>
		
        <?php
        include "modules/menu.php";
        ?>

</div>
</div>
</div>
</div>
	<!-- start slider -->
	<div class="slider">
		<div class="image-slider">
			<!-- Slideshow 1 -->
			<ul class="rslides" id="slider1">
				<li><img src="views/images/slider1.jpg" alt=""></li>
				<li><img src="views/images/slider2.jpg" alt=""></li>
				<li><img src="views/images/slider3.jpg" alt=""></li>
			</ul>
		<!-- Slideshow 2 -->
		</div>
		<!--End-image-slider---->
	</div>
<!-- start content -->

<?php
    $mvc = new MvcController();
    $mvc -> enlacesPaginasController();
?>

<!-- start footer -->
<div class="footer_bg">
<div class="wrap">
<div class="wrapper">
<div class="footer">
	<div class="section group">
		
		<div class="col_1_of_3 span_1_of_3">
			<h3>Contáctenos</h3>
			<ul class="f_nav">
				<li>Lorem Ipsum available,</li>
				<li>22-56-2-9 Sit Amet, Lorem,</li>
				<li>There are many variations,</li>
				<li>USA</li>
				<li>fax:(00) 000 000 000 </li>
				<li>Phone:(00) 222 666 444 </li>
				<li>Email:<a href=""> <span><a href="mailto:info@example.com">mail@example.com</a></span></a></li>
			</ul>
		</div>
		<div class="clear"></div>
	</div>
</div>
</div>
</div>
</div>
<div class="f_bg">
<div class="wrap">
<div class="wrapper">
	<div class="footer1">
		<div class="social-icons">
	   		  	
                     <a href="https://www.facebook.com/hector.beltran.1272/" target="_blank"><img src="views/images/icon1.png" alt=""></a>
			      <div class="clear"></div>
		     
		 </div>
	 	<div class="logo1 logo_social">
		 	<a href="index.php"><img src="views/images/logo1.png"> </a>
		</div>
		<div class="copy">
			<p class="link"><span>© Desarrollado por Heidy N. Mahecha - Héctor A. Beltrán | © Quarry. All rights reserved | Design by&nbsp; <a href="http://w3layouts.com/"> W3Layouts</a></span></p>
		</div>
	</div>
</div>
</div>
</div>
</body>
</html>